#include <stdio.h>
#include <string.h>
int search(const char *text,const char *pat,long *count){
    int n=strlen(text),m=strlen(pat);*count=0;
    for(int i=0;i<=n-m;i++){int j=0;
        while(j<m){(*count)++;if(text[i+j]!=pat[j])break;j++;}
        if(j==m)return i;
    }return -1;
}
int main(void){
    const char *texts[]={"security alert: login failed","aaaaaaaaaaaaaaaaab","ababababababababac"};
    const char *patterns[]={"alert","aaaaab","ababac"};
    puts("Q3: Brute-force string matching");
    for(int i=0;i<3;i++){long c;int p=search(texts[i],patterns[i],&c);
        printf("Test %d: text_length=%zu pattern=%s result=%d character_comparisons=%ld\n",i+1,strlen(texts[i]),patterns[i],p,c);}
    return 0;
}
