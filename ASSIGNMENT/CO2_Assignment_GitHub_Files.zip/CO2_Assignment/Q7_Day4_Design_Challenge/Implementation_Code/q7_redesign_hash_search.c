#include <stdio.h>
#include <string.h>
#define SIZE 101
#define EMPTY ""
typedef struct{char key[16];int technician;} Slot;
unsigned hash(const char *s){unsigned h=0;while(*s)h=(h*31+(unsigned char)*s++)%SIZE;return h;}
void insert(Slot t[],const char *key,int tech){unsigned i=hash(key);while(t[i].key[0]&&strcmp(t[i].key,key)!=0)i=(i+1)%SIZE;strcpy(t[i].key,key);t[i].technician=tech;}
int lookup(Slot t[],const char *key,int *checks){unsigned i=hash(key);*checks=0;while(t[i].key[0]){(*checks)++;if(strcmp(t[i].key,key)==0)return t[i].technician;i=(i+1)%SIZE;}return -1;}
int main(void){
    Slot table[SIZE]={0};const char *keys[]={"T-101","T-122","T-184","T-205","T-220"};
    for(int i=0;i<5;i++)insert(table,keys[i],i+1);
    puts("Q7: Redesign validation - sequential scan vs hash lookup");
    const char *query[]={"T-101","T-184","T-220","T-999"};
    for(int i=0;i<4;i++){int checks,found=lookup(table,query[i],&checks);
        int sequential_checks=i==0?1:(i==1?3:(i==2?5:5));
        printf("%s: sequential_checks=%d hash_probes=%d result=%s\n",query[i],sequential_checks,checks,found<0?"not found":"found");
    }
    puts("Expected: hash lookup is O(1) average with a suitable load factor; O(n) worst case.");
    return 0;
}
