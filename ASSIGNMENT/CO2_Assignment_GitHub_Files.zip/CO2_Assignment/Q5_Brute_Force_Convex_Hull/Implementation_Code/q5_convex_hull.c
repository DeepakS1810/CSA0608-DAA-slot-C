#include <stdio.h>
#include <math.h>
typedef struct{double x,y;} Point;
double cross(Point a,Point b,Point c){return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);}
int main(void){
    Point p[]={{0,0},{4,0},{4,4},{0,4},{2,2},{1,1},{3,2},{2,0}};
    int n=8,edge[8][8]={0};long tests=0;
    puts("Q5: Brute-force convex hull");
    for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
        int pos=0,neg=0;
        for(int k=0;k<n;k++)if(k!=i&&k!=j){double z=cross(p[i],p[j],p[k]);tests++;if(z>1e-9)pos=1;else if(z< -1e-9)neg=1;}
        if(!(pos&&neg)){edge[i][j]=edge[j][i]=1;}
    }
    puts("Accepted supporting-line endpoint pairs (collinear boundary points may also appear):");
    for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)if(edge[i][j])
        printf("(%.0f,%.0f) -- (%.0f,%.0f)\n",p[i].x,p[i].y,p[j].x,p[j].y);
    printf("orientation_tests=%ld theoretical_upper_bound=%d\n",tests,n*(n-1)*(n-2)/2);
    puts("Hull corner set for this square: (0,0), (4,0), (4,4), (0,4)");
    return 0;
}
