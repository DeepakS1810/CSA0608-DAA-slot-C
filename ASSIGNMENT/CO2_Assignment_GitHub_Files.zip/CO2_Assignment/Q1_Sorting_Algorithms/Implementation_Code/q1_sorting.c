#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
typedef struct { long comparisons, moves; } Stats;
void selection(int a[], int n, Stats *s) {
    for (int i=0;i<n-1;i++) { int m=i;
        for (int j=i+1;j<n;j++) { s->comparisons++; if(a[j]<a[m]) m=j; }
        if(m!=i){ int t=a[i]; a[i]=a[m]; a[m]=t; s->moves+=3; }
    }
}
void bubble(int a[], int n, Stats *s) {
    for(int i=0;i<n-1;i++){ int changed=0;
        for(int j=0;j<n-i-1;j++){ s->comparisons++;
            if(a[j]>a[j+1]){int t=a[j];a[j]=a[j+1];a[j+1]=t;s->moves+=3;changed=1;}
        } if(!changed) break;
    }
}
void insertion(int a[], int n, Stats *s) {
    for(int i=1;i<n;i++){int key=a[i],j=i-1;s->moves++;
        while(j>=0){s->comparisons++;if(a[j]>key){a[j+1]=a[j];s->moves++;j--;}else break;}
        a[j+1]=key;s->moves++;
    }
}
void run(const char *name, void (*fn)(int[],int,Stats*), int src[], int n) {
    int *a=malloc(n*sizeof(int)); memcpy(a,src,n*sizeof(int)); Stats s={0,0};
    clock_t st=clock(); fn(a,n,&s); double ms=1000.0*(clock()-st)/CLOCKS_PER_SEC;
    printf("%-11s comparisons=%ld moves=%ld time_ms=%.3f sorted=",name,s.comparisons,s.moves,ms);
    for(int i=0;i<n;i++) printf("%d%s",a[i],i==n-1?"":" ");
    puts(""); free(a);
}
int main(void){
    int random[]={8,3,7,1,9,2,6,4,5};
    int nearly[]={1,2,3,5,4,6,7,8,9};
    int sorted[]={1,2,3,4,5,6,7,8,9};
    puts("Q1: Sorting experiment (n=9)");
    puts("Dataset: random"); run("Selection",selection,random,9);run("Bubble",bubble,random,9);run("Insertion",insertion,random,9);
    puts("Dataset: nearly sorted");run("Selection",selection,nearly,9);run("Bubble",bubble,nearly,9);run("Insertion",insertion,nearly,9);
    puts("Dataset: sorted edge case");run("Selection",selection,sorted,9);run("Bubble",bubble,sorted,9);run("Insertion",insertion,sorted,9);
    return 0;
}
