#include <stdio.h>
#define MAX 20
typedef struct{int weight,value;} Item;
int main(void){
    Item a[]={{2,12},{1,10},{3,20},{2,15}};int n=4,capacity=5;
    long candidates=0,feasible=0;int best=-1,bestmask=0;
    for(int mask=0;mask<(1<<n);mask++){int w=0,v=0;candidates++;
        for(int i=0;i<n;i++)if(mask&(1<<i)){w+=a[i].weight;v+=a[i].value;}
        if(w<=capacity){feasible++;if(v>best){best=v;bestmask=mask;}}
    }
    printf("Q6: Exhaustive knapsack capacity=%d\n",capacity);
    printf("packages=%d candidates=%ld feasible=%ld best_value=%d\n",n,candidates,feasible,best);
    printf("selected packages:");
    for(int i=0;i<n;i++)if(bestmask&(1<<i))printf(" P%d",i+1);
    puts("");
    puts("Growth: n=4 -> 16, n=10 -> 1024, n=15 -> 32768, n=20 -> 1048576 subsets");
    return 0;
}
