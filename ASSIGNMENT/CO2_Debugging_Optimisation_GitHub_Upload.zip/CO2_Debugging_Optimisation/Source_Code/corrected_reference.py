"""Corrected reference implementations, retaining the original algorithms."""
from math import sqrt

def sort_alerts(alerts):
    for i in range(1, len(alerts)):
        key = alerts[i]
        j = i - 1
        while j >= 0 and alerts[j][1] < key[1]:
            alerts[j + 1] = alerts[j]
            j -= 1
        alerts[j + 1] = key
    return alerts

def is_blocked(blocklist, ip):
    for item in blocklist:
        if item == ip:
            return True
    return False

def find_signature(log, pattern):
    n, m = len(log), len(pattern)
    if m == 0:
        return list(range(n + 1))
    if m > n:
        return []
    hits = []
    for i in range(n - m + 1):
        j = 0
        while j < m and log[i + j] == pattern[j]:
            j += 1
        if j == m:
            hits.append(i)
    return hits

def closest_logins(events):
    if len(events) < 2:
        return None, float("inf")
    min_sq = float("inf")
    pair = None
    for i in range(len(events)):
        for j in range(i + 1, len(events)):
            dx = events[i][0] - events[j][0]
            dy = events[i][1] - events[j][1]
            d_sq = dx * dx + dy * dy
            if d_sq < min_sq:
                min_sq = d_sq
                pair = (i, j)
    return pair, sqrt(min_sq)
