"""Repeatable tests and experiment runner for SentinelOps."""
import random
import time
from optimized_module import sort_alerts, is_blocked, find_signature, closest_logins
from corrected_reference import closest_logins as brute_closest

def run_tests():
    alerts = [("A1", 3), ("A2", 9), ("A3", 5), ("A4", 9), ("A5", 1)]
    assert sort_alerts(alerts.copy()) == [("A2",9),("A4",9),("A3",5),("A1",3),("A5",1)]
    assert sort_alerts([]) == []
    assert sort_alerts([("x", 4), ("y", 4)]) == [("x", 4), ("y", 4)]

    blocked = {"10.0.0.5", "10.0.0.9", "172.16.4.2"}
    assert is_blocked(blocked, "10.0.0.9") is True
    assert is_blocked(blocked, "8.8.8.8") is False
    assert is_blocked(set(), "8.8.8.8") is False

    assert find_signature("FAILFAIXFAIL", "FAIL") == [0, 8]
    assert find_signature("ABCXYZ", "XYZ") == [3]       # final legal start
    assert find_signature("ABC", "ABCDE") == []
    assert find_signature("", "A") == []
    assert find_signature("ABC", "") == [0, 1, 2, 3]
    assert find_signature("AAAA", "AA") == [0, 1, 2]   # overlaps

    events = [(2,3), (12,30), (40,50), (5,1), (12,10), (3,4)]
    pair, dist, checks = closest_logins(events)
    assert pair == (0,5) and abs(dist - math_dist((2,3),(3,4))) < 1e-12
    assert closest_logins([])[0] is None
    assert closest_logins([(1,2)])[0] is None
    assert closest_logins([(0,0),(0,0)])[0] == (0,1)
    print("All functional and boundary tests passed.")

def math_dist(a,b):
    return ((a[0]-b[0])**2 + (a[1]-b[1])**2) ** 0.5

def run_experiments():
    rng = random.Random(2026)
    rows = []
    for n in (1000, 4000, 8000):
        pts = [(rng.random()*10000, rng.random()*10000) for _ in range(n)]
        _, _, opt_checks = closest_logins(pts)
        # The full brute-force comparison count is exact and does not need
        # executing the very expensive loop just to count its comparisons.
        brute_checks = n * (n - 1) // 2
        rows.append((n, brute_checks, opt_checks))
    print("\\nClosest-pair distance calculations (same input batches):")
    print("n, brute_force, x_sweep_pruned")
    for row in rows:
        print(*row, sep=", ")

if __name__ == "__main__":
    import math
    run_tests()
    run_experiments()
