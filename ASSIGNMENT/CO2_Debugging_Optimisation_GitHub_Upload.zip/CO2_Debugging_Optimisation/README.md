# CO2 Debugging and Optimisation – SentinelOps

## Repository structure
- `Pseudocode/` – pseudocode for all four algorithms.
- `Source_Code/original_buggy.py` – supplied program as transcribed.
- `Source_Code/corrected_reference.py` – corrected reference algorithms.
- `Source_Code/optimized_module.py` – production-oriented implementations.
- `Source_Code/test_harness.py` – functional/boundary tests and experiment runner.
- `Report/` – full report (DOCX and PDF).
- `Supporting_Files/` – CSV measurements, execution log and graphs.

## Run
Use Python 3.10+; no third-party packages are required for the source algorithms.

```bash
cd Source_Code
python test_harness.py
```

The harness verifies normal and boundary cases and prints closest-pair comparison counts for 1,000, 4,000 and 8,000 events. The CSV files and graphs in `Supporting_Files/` contain repeatable experimental data.

## Important design notes
- Alerts are sorted in-place, descending by severity, and stably for equal severities.
- Repeated blocklist lookups should use a set constructed once when the blocklist is loaded.
- Brute-force matching checks all legal start positions and reports overlapping matches.
- The closest-pair sweep uses x-ordering and a horizontal-distance pruning bound. It is worst-case O(n²), but can prune many candidates on spatially spread data.
