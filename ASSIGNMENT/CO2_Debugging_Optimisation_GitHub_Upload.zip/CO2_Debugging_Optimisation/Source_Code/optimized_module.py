"""Corrected and optimised SentinelOps alert-triage algorithms."""
from math import sqrt
from typing import Iterable, List, Sequence, Tuple, Optional

Alert = Tuple[str, int]
Point = Tuple[float, float]


def sort_alerts(alerts: List[Alert]) -> List[Alert]:
    """Stable in-place insertion sort: descending severity."""
    for i in range(1, len(alerts)):
        key = alerts[i]
        j = i - 1
        # Strict comparison preserves arrival order for equal severities.
        while j >= 0 and alerts[j][1] < key[1]:
            alerts[j + 1] = alerts[j]
            j -= 1
        alerts[j + 1] = key
    return alerts


def is_blocked(blocklist: Iterable[str], ip: str) -> bool:
    """Return True iff ip occurs in blocklist; use a set for repeated queries."""
    # The public API accepts any iterable; callers should pass a set for O(1)
    # average membership tests when checking many IPs.
    if isinstance(blocklist, (set, frozenset)):
        return ip in blocklist
    return ip in blocklist


def find_signature(log: str, pattern: str) -> List[int]:
    """Return every (including overlapping) start index using brute force."""
    n, m = len(log), len(pattern)
    if m == 0:
        return list(range(n + 1))
    if m > n:
        return []
    hits = []
    # Every legal start, including n-m, must be tested.
    for start in range(n - m + 1):
        offset = 0
        while offset < m and log[start + offset] == pattern[offset]:
            offset += 1
        if offset == m:
            hits.append(start)
    return hits


def closest_logins(events: Sequence[Point]) -> Tuple[Optional[Tuple[int, int]], float, int]:
    """Closest pair by Euclidean distance.

    Returns ((original_index_a, original_index_b), distance, distance_checks).
    The x-sorted sweep prunes a candidate when its horizontal separation alone
    exceeds the best known distance. Worst-case time remains O(n^2).
    """
    n = len(events)
    if n < 2:
        return None, float("inf"), 0

    ordered = sorted((x, y, idx) for idx, (x, y) in enumerate(events))
    best_sq = float("inf")
    best_pair = None
    checks = 0

    for pos in range(n):
        x, y, original_i = ordered[pos]
        prev = pos - 1
        while prev >= 0:
            px, py, original_j = ordered[prev]
            dx = x - px
            if dx * dx > best_sq:
                break
            dy = y - py
            d_sq = dx * dx + dy * dy
            checks += 1
            candidate = tuple(sorted((original_i, original_j)))
            if (d_sq < best_sq or
                (d_sq == best_sq and (best_pair is None or candidate < best_pair))):
                best_sq = d_sq
                best_pair = candidate
            prev -= 1

    return best_pair, sqrt(best_sq), checks
