#include <stdio.h>
#include <math.h>
#include <time.h>
typedef struct{double x,y;} Point;
void closest(Point p[],int n,int *a,int *b,long *pairs,long *distances,double *best){
    *best=1e100;*pairs=0;*distances=0;
    for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
        (*pairs)++;(*distances)++;
        double dx=p[i].x-p[j].x,dy=p[i].y-p[j].y,d=sqrt(dx*dx+dy*dy);
        if(d<*best){*best=d;*a=i;*b=j;}
    }
}
int main(void){
    Point p[]={{0,0},{3,4},{1,1},{8,8},{2,2},{-1,0},{10,2},{4,4}};
    int sizes[]={4,6,8};
    puts("Q4: Brute-force closest pair");
    for(int k=0;k<3;k++){int a=0,b=1;long pairs,dist;double best;
        closest(p,sizes[k],&a,&b,&pairs,&dist,&best);
        printf("n=%d unique_pairs=%ld distance_calculations=%ld closest=(%.0f,%.0f)-(%.0f,%.0f) distance=%.3f\n",
        sizes[k],pairs,dist,p[a].x,p[a].y,p[b].x,p[b].y,best);
    }
    puts("Theoretical unique pairs = n(n-1)/2; for n=1000: 499500");
    return 0;
}
