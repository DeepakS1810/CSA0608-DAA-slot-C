#include <stdio.h>
typedef struct { char tool[10]; char tech[10]; char time[10]; int bay; } Record;
int sequential(Record a[], int n, const char *key, int *comparisons){
    *comparisons=0;
    for(int i=0;i<n;i++){(*comparisons)++; if(a[i].tool[0]==key[0] && __builtin_strcmp(a[i].tool,key)==0) return i;}
    return -1;
}
int main(void){
    Record a[]={{"T-101","TECH1","09:00",1},{"T-122","TECH2","09:15",2},{"T-184","TECH3","09:30",4},{"T-205","TECH4","09:45",3},{"T-220","TECH5","10:00",1}};
    const char *keys[]={"T-101","T-184","T-220","T-999"};
    puts("Q2: Aircraft tool tracking - sequential search");
    for(int k=0;k<4;k++){int c,pos=sequential(a,5,keys[k],&c);
        if(pos>=0) printf("%s found: technician=%s bay=%d comparisons=%d\n",keys[k],a[pos].tech,a[pos].bay,c);
        else printf("%s not found comparisons=%d\n",keys[k],c);
    }
    puts("List-size worst-case comparisons: n=5 -> 5, n=20 -> 20, n=100 -> 100, n=1000 -> 1000");
    return 0;
}
