# CO2 Assignment – Brute Force and Exhaustive Search

**Language:** C  
**Questions:** Q1–Q7  
**Build:** `gcc filename.c -o program -lm` (use `-lm` for programs using math functions)

## Repository contents
- `Q1_Sorting_Algorithms` – Selection, Bubble and Insertion Sort
- `Q2_Sequential_Search` – Aircraft tool tracking
- `Q3_Brute_Force_String_Matching` – Character comparison experiment
- `Q4_Brute_Force_Closest_Pair` – Unique pair enumeration
- `Q5_Brute_Force_Convex_Hull` – Supporting-line test
- `Q6_Exhaustive_Search` – 0/1 knapsack enumeration
- `Q7_Day4_Design_Challenge` – Sequential lookup redesigned with hashing
- `Final_Report` – Full report (submit the separate DOCX file)

Each question folder has `Pseudocode`, `Implementation_Code`, and `Output_Screenshots`. The screenshot PNGs are generated from the captured output of the compiled programs. Recompile and run locally to verify on your system.

## Compile and run
Example:
```bash
gcc Q1_Sorting_Algorithms/Implementation_Code/q1_sorting.c -o q1
./q1
```
For Q4/Q5 use `-lm`:
```bash
gcc Q4_Brute_Force_Closest_Pair/Implementation_Code/q4_closest_pair.c -o q4 -lm
./q4
```

## Notes
Operation counts are the primary evidence; execution time is machine-dependent. Results in the report correspond to the supplied test datasets and program versions. The Q5 implementation identifies supporting-line candidate pairs; for collinear boundary points, a production polygon-ordering stage and a consistent collinearity policy are required.
